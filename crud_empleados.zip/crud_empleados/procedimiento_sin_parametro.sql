-- vamos a crear un procedimiento almacenado sin parametros

DELIMITER //
-- ESTABLECEMOS EL NOMBRE DEL PROCEDIMIENTO
CREATE PROCEDURE verEmpleados()
BEGIN

SELECT * FROM Empleados;

END //

DELIMITER ;

-- INVOCAMOS/REALISAMOS AL PROCEDIMIENTO ANTERIOR

CALL verEmpleados;




