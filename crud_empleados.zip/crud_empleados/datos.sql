INSERT INTO empleados (Id_empleado,Nombre_empleado,Salario)VALUES
(1,"Daniela",500000),
(2,"sara",300000),
(3,"Dana",600000),
(4,"Daniel",700000),
(5,"mara",350000),
(6,"maria",450000);
select*from empleados;