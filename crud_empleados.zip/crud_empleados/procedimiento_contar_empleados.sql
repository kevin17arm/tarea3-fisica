DROP PROCEDURE IF EXISTS contarEmpleados;

DELIMITER //
CREATE PROCEDURE contarEmpleados(OUT total INT)
BEGIN
    SELECT COUNT(*) INTO total
    FROM empleados;
END //
DELIMITER ;

CALL contarEmpleados(@resultado);
SELECT @resultado AS TotalEmpleados;
