-- creamos un procedimiento almacenado pero con parametros de entrada

DELIMITER //

CREATE PROCEDURE verSalario ( IN SalarioMinimo DECIMAL(10,2) )

BEGIN
 SELECT Nombre_empleado,salario
 From empleados
 WHERE salario >= SalarioMinimo;

END //

DELIMITER ;
-- invocamos el procedimiento asumiendo un parametro de entrada salariominimo = 25000000
CALL verSalario(450000);
